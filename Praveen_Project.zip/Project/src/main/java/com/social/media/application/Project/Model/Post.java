package com.social.media.application.Project.Model;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

public class Post {
	
	 private String postId;
	    private String content;
	    private LocalDateTime postTime;
	    private String userId;
	    private int likes;
	    private int dislikes;
	    private Set<String> likedBy;
	    private Set<String> dislikedBy;

	    public Post(String postId, String content, String userId) {
	        this.postId = postId;
	        this.content = content;
	        this.userId = userId;
	        this.postTime = LocalDateTime.now();
	        this.likes = 0;
	        this.dislikes = 0;
	        this.likedBy = new HashSet<>();
	        this.dislikedBy = new HashSet<>();
	    }

	    public String getPostId() {
	        return postId;
	    }

	    public String getContent() {
	        return content;
	    }

	    public LocalDateTime getPostTime() {
	        return postTime;
	    }

	    public String getUserId() {
	        return userId;
	    }

	    public int getLikes() {
	        return likes;
	    }

	    public int getDislikes() {
	        return dislikes;
	    }

	    /**
	     * Likes the post by the given user. If the user had already disliked the post,
	     * the dislike is removed.
	     */
	    public void like(String userId) {
	        if(likedBy.contains(userId)) {
	            // User already liked.
	            return;
	        }
	        if(dislikedBy.contains(userId)) {
	            dislikedBy.remove(userId);
	            dislikes--;
	        }
	        likedBy.add(userId);
	        likes++;
	    }

	    /**
	     * Dislikes the post by the given user. If the user had already liked the post,
	     * the like is removed.
	     */
	    public void dislike(String userId) {
	        if(dislikedBy.contains(userId)) {
	            return;
	        }
	        if(likedBy.contains(userId)) {
	            likedBy.remove(userId);
	            likes--;
	        }
	        dislikedBy.add(userId);
	        dislikes++;
	    }

}
