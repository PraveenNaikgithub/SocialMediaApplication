package com.social.media.application.Project;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.social.media.application.Project.Model.Post;
import com.social.media.application.Project.Model.User;
@SpringBootApplication
public class SocialMediaApp {
	
	 private Map<String, User> users;
	    private Map<String, Post> posts;
	    private int postCounter;

	    public SocialMediaApp() {
	        users = new HashMap<>();
	        posts = new HashMap<>();
	        postCounter = 0;
	    }

	    public void registerUser(String userId, String userName) {
	        if(users.containsKey(userId)) {
	            System.out.println("User with id " + userId + " already exists.");
	            return;
	        }
	        User newUser = new User(userId, userName);
	        users.put(userId, newUser);
	        System.out.println(userName + " Registered!!");
	    }

	   
	    public void uploadPost(String userId, String content) {
	        User user = users.get(userId);
	        if(user == null) {
	            System.out.println("User with id " + userId + " not found.");
	            return;
	        }
	        postCounter++;
	        String postId = String.format("%03d", postCounter);
	        Post newPost = new Post(postId, content, userId);
	        posts.put(postId, newPost);
	        user.addPost(newPost);
	        System.out.println("Upload Successful with post id: " + postId);
	    }

	 
	    public void interactWithUser(String interactionType, String userId1, String userId2) {
	        User actor = users.get(userId1);
	        User target = users.get(userId2);
	        if(actor == null || target == null) {
	            System.out.println("User not found for follow/unfollow.");
	            return;
	        }
	        if(interactionType.equalsIgnoreCase("FOLLOW")) {
	            actor.follow(userId2);
	            System.out.println("Followed " + target.getUserName() + "!");
	        } else if(interactionType.equalsIgnoreCase("UNFOLLOW")) {
	            actor.unfollow(userId2);
	            System.out.println("Unfollowed " + target.getUserName() + "!!");
	        } else {
	            System.out.println("Invalid interaction type.");
	        }
	    }

	  
	    public void interactWithPost(String interactionType, String userId, String postId) {
	        User user = users.get(userId);
	        Post post = posts.get(postId);
	        if(user == null || post == null) {
	            System.out.println("User or Post not found for interaction.");
	            return;
	        }
	        if(interactionType.equalsIgnoreCase("LIKE")) {
	            post.like(userId);
	            System.out.println("Post Liked!!");
	        } else if(interactionType.equalsIgnoreCase("DISLIKE")) {
	            post.dislike(userId);
	            System.out.println("Post Disliked!!");
	        } else {
	            System.out.println("Invalid interaction type for post.");
	        }
	    }



	    public void showFeed(String userId) {
	        User currentUser = users.get(userId);
	        if(currentUser == null) {
	            System.out.println("User with id " + userId + " not found.");
	            return;
	        }
	        // Collect all posts from the system.
	        List<Post> allPosts = new ArrayList<>(posts.values());

	        // Sort posts based on whether the post’s owner is followed and by post time descending.
	        allPosts.sort((p1, p2) -> {
	            boolean p1Followed = currentUser.getFollowing().contains(p1.getUserId());
	            boolean p2Followed = currentUser.getFollowing().contains(p2.getUserId());
	            if(p1Followed && !p2Followed) {
	                return -1;
	            } else if(!p1Followed && p2Followed) {
	                return 1;
	            } else {
	                // Both posts in the same group; sort by post time descending.
	                return p2.getPostTime().compareTo(p1.getPostTime());
	            }
	        });

	        // Display each post in the feed.
	        for(Post post : allPosts) {
	            User postUser = users.get(post.getUserId());
	            String userName = (postUser != null) ? postUser.getUserName() : "Unknown";
	            String relativeTime = getRelativeTime(post.getPostTime());
	            System.out.println("UserName - " + userName);
	            System.out.println("# of Likes - " + post.getLikes());
	            System.out.println("# of Dislikes - " + post.getDislikes());
	            System.out.println("Post - " + post.getContent());
	            System.out.println("Post time - " + relativeTime);
	            System.out.println("---------------------------");
	        }
	    }



	    private String getRelativeTime(LocalDateTime postTime) {
	        Duration duration = Duration.between(postTime, LocalDateTime.now());
	        long seconds = duration.getSeconds();
	        if(seconds < 60) {
	            return seconds + "s ago";
	        }
	        long minutes = seconds / 60;
	        if(minutes < 60) {
	            return minutes + "m ago";
	        }
	        long hours = minutes / 60;
	        if(hours < 24) {
	            return hours + "h ago";
	        }
	        long days = hours / 24;
	        return days + "d ago";
	    }


	    public static void main(String[] args) {
	    	SpringApplication.run(SocialMediaApp.class, args);
	        SocialMediaApp app = new SocialMediaApp();
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Welcome to ClearTrip Social Media Console Application");
	        System.out.println("Enter commands (type 'exit' to quit):");
	        while (true) {
	            String input = sc.nextLine();
	            if(input.equalsIgnoreCase("exit")) {
	                break;
	            }
	            // Split command into at most 3 parts so that posts with spaces are captured.
	            String[] parts = input.split(" ", 3);
	            if(parts.length < 2) {
	                System.out.println("Invalid command format.");
	                continue;
	            }
	            String command = parts[0];
	            try {
	                switch(command) {
	                    case "RegisterUser":
	                        if(parts.length < 3) {
	                            System.out.println("Usage: RegisterUser <user_id> <user_name>");
	                        } else {
	                            String userId = parts[1];
	                            String userName = parts[2];
	                            app.registerUser(userId, userName);
	                        }
	                        break;
	                    case "UploadPost":
	                        if(parts.length < 3) {
	                            System.out.println("Usage: UploadPost <user_id> <post>");
	                        } else {
	                            String userId = parts[1];
	                            String postContent = parts[2];
	                            // Remove surrounding quotes if present.
	                            postContent = postContent.replaceAll("^\"|\"$", "");
	                            app.uploadPost(userId, postContent);
	                        }
	                        break;
	                    case "InteractWithUser":
	                        String[] userParts = parts[2].split(" ");
	                        if(userParts.length < 2) {
	                            System.out.println("Usage: InteractWithUser <interaction_type> <user_id1> <user_id2>");
	                        } else {
	                            String interactionType = parts[1];
	                            String userId1 = userParts[0];
	                            String userId2 = userParts[1];
	                            app.interactWithUser(interactionType, userId1, userId2);
	                        }
	                        break;
	                    case "InteractWithPost":
	                        String[] postParts = parts[2].split(" ");
	                        if(postParts.length < 2) {
	                            System.out.println("Usage: InteractWithPost <interaction_type> <user_id> <post_id>");
	                        } else {
	                            String interactionTypePost = parts[1];
	                            String userId = postParts[0];
	                            String postId = postParts[1];
	                            app.interactWithPost(interactionTypePost, userId, postId);
	                        }
	                        break;
	                    case "ShowFeed":
	                   
	                        String feedUserId = parts[1];
	                        app.showFeed(feedUserId);
	                        break;
	                    default:
	                        System.out.println("Unknown command.");
	                }
	            } catch(Exception e) {
	                System.out.println("Error processing command: " + e.getMessage());
	            }
	        }
	        sc.close();
	    }

}
