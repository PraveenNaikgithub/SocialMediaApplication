package com.social.media.application.Project.Model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class User {

	
	private String userId;
    private String userName;
    private Set<String> following;
    private List<Post> posts;

    public User(String userId, String userName) {
        this.userId = userId;
        this.userName = userName;
        this.following = new HashSet<>();
        this.posts = new ArrayList<>();
        // By default, user follows themselves so that their own posts appear at the top.
        this.following.add(userId);
    }

    public String getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public Set<String> getFollowing() {
        return following;
    }

    public List<Post> getPosts() {
        return posts;
    }

    public void addPost(Post post) {
        posts.add(post);
    }

    public void follow(String otherUserId) {
        following.add(otherUserId);
    }

    public void unfollow(String otherUserId) {
     
        if(otherUserId.equals(this.userId)) {
            System.out.println("Cannot unfollow self.");
            return;
        }
        following.remove(otherUserId);
    }
	
}
